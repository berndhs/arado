CREATE TABLE "urltable" (
    "hashid" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "description" TEXT NOT NULL
);
