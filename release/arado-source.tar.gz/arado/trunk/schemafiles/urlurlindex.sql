CREATE INDEX "urlurlindex" on urltable (url ASC);
