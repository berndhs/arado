CREATE UNIQUE INDEX "keyindex" on keywords (hashid ASC, keyword ASC)

