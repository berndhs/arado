CREATE TABLE "keywords" (
    "hashid" TEXT NOT NULL,
    "keyword" TEXT NOT NULL
);
