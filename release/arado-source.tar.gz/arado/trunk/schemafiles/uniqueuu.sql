CREATE UNIQUE INDEX "uniqueuu" on peeruuid (uuid ASC)
