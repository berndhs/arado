CREATE UNIQUE INDEX "ippeerindex" on ippeers (peerid ASC)
