CREATE TABLE "transientpeers" (
  "peerid" TEXT NOT NULL,
  "peerclass" TEXT NOT NULL
)
