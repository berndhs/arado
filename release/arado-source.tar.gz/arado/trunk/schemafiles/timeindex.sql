CREATE INDEX "timeindex" on timestamps (incoming DESC)

