CREATE TABLE "timestamps" (
    "hashid" TEXT NOT NULL,
    "incoming" INTEGER NOT NULL
)

