CREATE UNIQUE INDEX "uuindex" on peeruuid (peerid ASC)
