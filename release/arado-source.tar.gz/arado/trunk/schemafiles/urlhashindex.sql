CREATE UNIQUE INDEX "urlhashindex" on urltable (hashid ASC);
