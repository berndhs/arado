CREATE TABLE "stablepeers" (
  "peerid" TEXT NOT NULL,
  "peerclass" TEXT NOT NULL
)
