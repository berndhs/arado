CREATE UNIQUE INDEX "stableindex" on stablepeers (peerid ASC)
