CREATE TABLE "ippeers" (
  "peerid" TEXT NOT NULL,
  "proto" TEXT NOT NULL,
  "address" TEXT NOT NULL,
  "port" TEXT NOT NULL
)
