CREATE TABLE "peeruuid" (
  "peerid" TEXT NOT NULL,
  "uuid" TEXT NOT NULL
)

