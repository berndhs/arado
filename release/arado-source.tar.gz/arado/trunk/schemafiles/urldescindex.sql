CREATE INDEX "urldescindex" on urltable (description ASC);
