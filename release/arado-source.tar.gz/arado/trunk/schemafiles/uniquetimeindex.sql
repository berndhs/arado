CREATE UNIQUE INDEX "uniquetimeindex" on timestamps (hashid DESC)

