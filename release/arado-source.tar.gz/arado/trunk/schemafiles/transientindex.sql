CREATE UNIQUE INDEX "transientindex" on transientpeers (peerid ASC)
